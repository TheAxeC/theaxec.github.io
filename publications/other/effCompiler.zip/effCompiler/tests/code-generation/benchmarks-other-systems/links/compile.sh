./links-effects/links -c queens_all.links -o queens_all
./links-effects/links -c queens_cps.links -o queens_cps
./links-effects/links -c queens_option.links -o queens_option
