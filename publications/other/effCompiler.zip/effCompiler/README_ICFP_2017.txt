To compile eff:

1) Run the make file using the command "make". This builds eff and generates a native excecutable.

2) To generate an ml file from an eff file run the following command :
     
     ./eff.native -n -V 4 --compile [filename]"

     * The command generates an ml file with the same name that runs on OCaml 2.0.2.

3) You can display the list of top-level options using the command:

     ./eff.native -help


-------------------------------------------------------------------------------------------------------

Notes on the implementation:

* We use the keyword "effect" instead of "operation" from the paper.

* We use the keyword "val" instead "return" in the return case of a handler.

* The part responsible of the term rewriting rules can be found in src/codegen/optimize.ml


--------------------------------------------------------------------------------------------------------

To Run the benchmarks :

1) The benchmarks for Eff vs OCaml can be found in the folder "tests/code-generation/benchmarks".

2) The benchmarks for Eff vs Other systems can be found in folder "tests/code-generation/bencmarks-other-systems".

3) Both folders contain a Readme file on how to run the respective benchmarks.
