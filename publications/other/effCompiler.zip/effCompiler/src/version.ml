let version = "4.0"
let effdir = "/usr/local/share/eff"
